import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefs {

	private int[] arr = new int[2];
	private int count;
	private int result;
	
	
	@Given("^I have entered (\\d+) into the calculator$")
	public void i_have_entered_into_the_calculator(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		arr[count++]=arg1;
		
	}

	@When("^I press add$")
	public void i_press_add() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		result=arr[0]+arr[1];
	}

	@Then("^the result should be (\\d+) on the screen$")
	public void the_result_should_be_on_the_screen(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		
		Assert.assertEquals(arg1, result);
	}



}
