package com.example.demotdd;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;
import com.example.controller.ControllerServlet;

@RunWith(MockitoJUnitRunner.class)
public class ControllerServletTest {
	
	@Mock
	private CarDAO carDAOref;
	
	@Mock
	private HttpServletRequest request;
	
	@Mock
	private HttpServletResponse response;
	
	@InjectMocks
	private ControllerServlet myServlet;
	
	@Test
	public void testProcessRequest() throws ServletException,IOException
	{
		//fail("Not yet Implemented");
		//Dont do this
		//myservlet = new ControllerServlet
		//SETUP
		//Stubbing behavior for mocked object using WHEN-THEN pattern
		//For VIEW CAR LIST
	Mockito.when(request.getParameter("action")).thenReturn("viewCarList");
	
	
	//DATA FIXTURE
	List<CarDTO> cars = new LinkedList<>();
	CarDTO car = new CarDTO();
	car.setId(1);
	car.setMake("Honda");
	car.setModel("City");
	car.setModelYear("2000");
	cars.add(car);
	
	Mockito.when(carDAOref.findAll()).thenReturn(cars);
	
	//EXECUTION
	myServlet.processRequest(request,response);
	
	//VERIFICATION
	Mockito.verify(request).getParameter("action");
	Mockito.verify(carDAOref).findAll();

}
	
	
	@Test
	public void testProcessRequest1() throws ServletException,IOException
	{
	//For EDIT CAR ACTION
		List<CarDTO> cars = new LinkedList<>();
		CarDTO car = new CarDTO();
		car.setId(1);
		car.setMake("Honda");
		car.setModel("City");
		car.setModelYear("2000");
		cars.add(car);
		
	Mockito.when(request.getParameter("action")).thenReturn("editCar");
	Mockito.when(request.getParameter("id")).thenReturn("1");
	Mockito.when(carDAOref.findById(1)).thenReturn(car);
	myServlet.processRequest(request, response);
	Mockito.verify(carDAOref).findById(1);
	}
	
	
	
	@Test
	public void testProcessRequest2() throws ServletException,IOException
	{
		//For DELETE CAR ACTION
		String[] arr = {"1","2","3"};
		Mockito.when(request.getParameter("action")).thenReturn("deleteCar");
		Mockito.when(request.getParameterValues("id")).thenReturn(arr);
		Mockito.doNothing().when(carDAOref).delete(arr);
		
		
		myServlet.processRequest(request, response);
		
		Mockito.verify(request).getParameter("action");
		
		Mockito.verify(carDAOref).delete(arr);
	}
	
	/*@Test
	public void testProcessRequest3() throws ServletException,IOException
	{
		Mockito.when(request.getParameter("action")).thenReturn("addCar");
		
		List<CarDTO> cars = new LinkedList<>();
		CarDTO car = new CarDTO();
		car.setId(5);
		car.setMake("Pulsar");
		car.setModel("220");
		car.setModelYear("2015");
		cars.add(car);
		
		Mockito.doNothing().when(carDAOref).create(car);
		
		myServlet.processRequest(request,response);
		
		Mockito.verify(request).getParameter("action");
		Mockito.verify(carDAOref).create(car);

	}
	*/
}
