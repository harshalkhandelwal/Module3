public class PathPages {

	static String url = "D:\\Users\\HARKHAND\\Desktop\\harshal\\Cucumber-Selenium-POM-Demo\\scr\\main\\webapp\\LoanApplicationPage.html";
	static String title = "Loan Application Page";
	
	public void goTo() {
		
		Browser.goTo(url);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}

	
	
}
